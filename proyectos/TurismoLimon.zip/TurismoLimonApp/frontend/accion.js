const params = new URLSearchParams(window.location.search);
const tipo = params.get('tipo');
const tabla = params.get('tabla');

const formAgregar = document.getElementById('form-hotel');
if (formAgregar) {
  formAgregar.addEventListener('submit', async (e) => {
    e.preventDefault();

    const datos = {};
    Array.from(e.target.elements).forEach(input => {
      if (input.name) datos[input.name] = input.value;
    });

    try {
      const res = await fetch('http://localhost:3000/api/hotel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
      });

      const resultado = await res.json();
      alert(resultado.mensaje || resultado.error);
    } catch (error) {
      alert('Error al conectar con el servidor');
      console.error(error);
    }
  });
}

// Escuchar formulario para eliminar hotel
const formEliminar = document.getElementById('form-eliminar-hotel');
if (formEliminar) {
  formEliminar.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = e.target.elements.idEliminar.value;

    try {
      const res = await fetch(`http://localhost:3000/api/hotel/${id}`, {
        method: 'DELETE'
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error del servidor: ${text}`);
      }

      const resultado = await res.json();
      alert(resultado.mensaje || resultado.error);
    } catch (error) {
      alert('Error al eliminar hotel');
      console.error(error);
    }
  });
}

if (tipo === 'modificar' && tabla === 'hotel') {
  document.getElementById('accion-contenido').innerHTML = `
    <h2>Modificar Hotel</h2>
    <form id="form-modificar-hotel">
      <input name="idHotel" placeholder="ID del hotel" type="number" required>
      <input name="NombreHotel" placeholder="Nombre del hotel" required>
      <input name="CedulaJuridica" placeholder="Cédula jurídica" required>
      <input name="Tipo" placeholder="Tipo (ej. Hotel 4 estrellas)" required>
      <input name="Provincia" placeholder="Provincia" required>
      <input name="Canton" placeholder="Cantón" required>
      <input name="Distrito" placeholder="Distrito" required>
      <input name="Barrio" placeholder="Barrio" required>
      <input name="SennasExactas" placeholder="Señas exactas" required>
      <input name="ReferenciaGPS" placeholder="Referencia GPS" required>
      <input name="CorreoElectronico" placeholder="Correo electrónico" required>
      <input name="UrlHotel" placeholder="URL del hotel" required>
      <select name="Activo" required>
        <option value="1">Activo</option>
        <option value="0">Inactivo</option>
      </select>
      <button type="submit">Modificar</button>
    </form>
  `;

  document.getElementById('form-modificar-hotel').addEventListener('submit', async (e) => {
    e.preventDefault();
    const datos = {};
    Array.from(e.target.elements).forEach(input => {
      if (input.name) datos[input.name] = input.value;
    });

    try {
      const res = await fetch(`http://localhost:3000/api/hotel/${datos.idHotel}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
      });

      const resultado = await res.json();
      alert(resultado.mensaje || resultado.error);
    } catch (error) {
      alert('Error al modificar el hotel');
      console.error(error);
    }
  });
}
const formConsultar = document.getElementById('form-consultar-hotel');
if (formConsultar) {
  formConsultar.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = new URLSearchParams();

    Array.from(e.target.elements).forEach(input => {
      if (input.name && input.value.trim()) {
        params.append(input.name, input.value.trim());
      }
    });

    try {
      const res = await fetch(`http://localhost:3000/api/hotel/consultar?${params.toString()}`);
      const hoteles = await res.json();

      if (!Array.isArray(hoteles)) throw new Error('Respuesta inesperada');

      const contenedor = document.getElementById('resultado-hoteles');
      if (hoteles.length === 0) {
        contenedor.innerHTML = '<p>No se encontraron hoteles con esos filtros.</p>';
        return;
      }

      let tabla = '<table border="1"><tr>';
      const columnas = Object.keys(hoteles[0]);
      tabla += columnas.map(col => `<th>${col}</th>`).join('') + '</tr>';

      hoteles.forEach(hotel => {
        tabla += '<tr>' + columnas.map(col => `<td>${hotel[col]}</td>`).join('') + '</tr>';
      });

      tabla += '</table>';
      contenedor.innerHTML = tabla;

    } catch (error) {
      console.error('Error al consultar hoteles:', error);
      document.getElementById('resultado-hoteles').innerHTML = '<p>Error al consultar hoteles.</p>';
    }
  });
}
if (tipo === 'consultar' && tabla === 'hotel') {
  document.getElementById('accion-contenido').innerHTML = `
    <section>
      <h2>Consultar Hoteles</h2>
      <form id="form-consultar-hotel">
        <input name="Provincia" placeholder="Provincia (opcional)">
        <input name="Canton" placeholder="Cantón (opcional)">
        <input name="Distrito" placeholder="Distrito (opcional)">
        <input name="Tipo" placeholder="Tipo (opcional)">
        <button type="submit">Consultar</button>
      </form>
      <div id="resultado-hoteles"></div>
    </section>
  `;

  document.getElementById('form-consultar-hotel').addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = new URLSearchParams();

    Array.from(e.target.elements).forEach(input => {
      if (input.name && input.value.trim()) {
        params.append(input.name, input.value.trim());
      }
    });

    try {
      const res = await fetch(`http://localhost:3000/api/hotel/consultar?${params.toString()}`);
      const hoteles = await res.json();

      const contenedor = document.getElementById('resultado-hoteles');

      if (!Array.isArray(hoteles)) throw new Error('Respuesta inesperada');

      if (hoteles.length === 0) {
        contenedor.innerHTML = '<p>No se encontraron hoteles.</p>';
        return;
      }

      let tabla = '<table border="1"><tr>';
      const columnas = Object.keys(hoteles[0]);
      tabla += columnas.map(col => `<th>${col}</th>`).join('') + '</tr>';

      hoteles.forEach(hotel => {
        tabla += '<tr>' + columnas.map(col => `<td>${hotel[col]}</td>`).join('') + '</tr>';
      });

      tabla += '</table>';
      contenedor.innerHTML = tabla;

    } catch (error) {
      console.error('Error al consultar hoteles:', error);
      document.getElementById('resultado-hoteles').innerHTML = '<p>Error al consultar hoteles.</p>';
    }
  });
}
