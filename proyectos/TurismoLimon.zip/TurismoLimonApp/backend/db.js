
const sql = require('mssql');

const config = {
  user: 'AdminHotel',
  password: 'Administrador123!',
  server: 'localhost',
  database: 'TurismoLimon',
  options: {
    encrypt: false,
    trustServerCertificate: true
  }
};


module.exports = { sql, config };
