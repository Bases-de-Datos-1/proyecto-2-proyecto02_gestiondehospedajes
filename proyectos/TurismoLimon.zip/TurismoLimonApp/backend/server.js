
const express = require('express');
const cors = require('cors');
const { sql, config } = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/hotel', (req, res) => {
  res.send('Ruta activa. Usa POST para agregar un hotel.');
});

app.post('/api/hotel', async (req, res) => {
  try {
    const datos = req.body;
    console.log('Datos recibidos:', datos);

    const pool = await sql.connect(config);
    await pool.request()
      .input('NombreHotel', sql.VarChar(100), datos.NombreHotel)
      .input('CedulaJuridica', sql.VarChar(20), datos.CedulaJuridica)
      .input('Tipo', sql.VarChar(30), datos.Tipo)
      .input('Provincia', sql.VarChar(50), datos.Provincia)
      .input('Canton', sql.VarChar(50), datos.Canton)
      .input('Distrito', sql.VarChar(50), datos.Distrito)
      .input('Barrio', sql.VarChar(100), datos.Barrio)
      .input('SennasExactas', sql.VarChar(250), datos.SennasExactas)
      .input('ReferenciaGPS', sql.VarChar(100), datos.ReferenciaGPS)
      .input('CorreoElectronico', sql.VarChar(100), datos.CorreoElectronico)
      .input('UrlHotel', sql.VarChar(100), datos.UrlHotel)
      .input('Activo', sql.Bit, 1)
      .execute('AgregarHotel');

    res.json({ mensaje: 'Hotel agregado con éxito' });
  } catch (err) {
    console.error('ERROR:', err);
    res.status(500).json({ error: 'Error al insertar hotel', detalle: err.message });
  }
});

app.listen(3000, () => {
  console.log('Servidor corriendo en puerto 3000');
});

app.delete('/api/hotel/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await sql.connect(config);
    await pool.request()
      .input('idHotel', sql.Int, id)
      .execute('EliminarHotel');
    res.json({ mensaje: 'Hotel eliminado correctamente.' });
  } catch (err) {
    console.error('ERROR:', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/hotel/:id', async (req, res) => {
  const { id } = req.params;
  const datos = req.body;

  try {
    const pool = await sql.connect(config);
    await pool.request()
      .input('idHotel', sql.Int, parseInt(id))
      .input('NombreHotel', sql.VarChar(100), datos.NombreHotel)
      .input('CedulaJuridica', sql.VarChar(20), datos.CedulaJuridica)
      .input('Tipo', sql.VarChar(30), datos.Tipo)
      .input('Provincia', sql.VarChar(50), datos.Provincia)
      .input('Canton', sql.VarChar(50), datos.Canton)
      .input('Distrito', sql.VarChar(50), datos.Distrito)
      .input('Barrio', sql.VarChar(100), datos.Barrio)
      .input('SennasExactas', sql.VarChar(250), datos.SennasExactas)
      .input('ReferenciaGPS', sql.VarChar(100), datos.ReferenciaGPS)
      .input('CorreoElectronico', sql.VarChar(100), datos.CorreoElectronico)
      .input('UrlHotel', sql.VarChar(100), datos.UrlHotel)
      .input('Activo', sql.Bit, parseInt(datos.Activo))
      .execute('ModificarHotel');

    res.json({ mensaje: 'Hotel modificado correctamente' });
  } catch (err) {
    console.error('ERROR en PUT:', err);

    // Este bloque extrae el mensaje del procedimiento
    const mensajeError = err.precedingErrors?.[0]?.message || err.message;

    res.status(500).json({
      error: 'Error al modificar hotel',
      detalle: mensajeError
    });
  }
});


app.get('/api/hotel/consultar', async (req, res) => {
  const { Provincia, Canton, Distrito, Tipo } = req.query;

  try {
    const pool = await sql.connect(config);
    const result = await pool.request()
      .input('Provincia', sql.VarChar(50), Provincia || null)
      .input('Canton', sql.VarChar(50), Canton || null)
      .input('Distrito', sql.VarChar(50), Distrito || null)
      .input('Tipo', sql.VarChar(30), Tipo || null)
      .execute('ConsultarHoteles');

    res.json(result.recordset);
  } catch (err) {
    console.error('Error al consultar hoteles:', err);
    res.status(500).json({ error: 'Error al consultar hoteles', detalle: err.message });
  }
});



